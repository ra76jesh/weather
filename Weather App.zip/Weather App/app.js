
async function getWeatherDetails() {
    const textInput = document.querySelector('#textInput').value;
    const city = document.querySelector('#city');
    const temp = document.querySelector('#temp');
    const speed = document.querySelector('#speed');
    const humidity = document.querySelector('#humidity');


    if (textInput === "") {
        alert("Please provide city name !!!");
    } else {
        const url = `https://api.openweathermap.org/data/2.5/weather?q=${textInput}&units=metric&appid=12b4472d69a4dedee9ba383ade046952`;
        const response = await fetch(url);
        const data = await response.json();
        console.log(data);

        city.innerText = data.name;
        temp.innerHTML = `${data.main.temp} <sup>o</sup>C | <sup>o</sup>F`;
        speed.textContent = data.wind.speed;
        humidity.textContent = data.main.humidity;
    }
}
